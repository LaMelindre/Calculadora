var Calculadora = {

  numero1: "",
  numero2: "",
  operacion:"",
  pantalla: document.getElementById("display"),

  escribir:function(numero) {
    if(Calculadora.pantalla.innerHTML.length<=7){
      if (Calculadora.pantalla.textContent === "0") {
        Calculadora.pantalla.textContent = numero;
      } else {
        Calculadora.pantalla.textContent += numero;
      }
    }
  },

init: function(){

  var uno=document.getElementById("1");
  uno.addEventListener("click", function() {
    Calculadora.escribir("1");
  })
  uno.addEventListener("mousedown",function(){
    uno.setAttribute("style","transform:scale(0.85,0.85)")
    })
    uno.addEventListener("mouseup",function(){
      uno.setAttribute("style","transform:scale(1,1)")
    })

  var dos = document.getElementById("2");
  dos.addEventListener("click", function() {
    Calculadora.escribir("2");
  })
  dos.addEventListener("mousedown",function(){
    dos.setAttribute("style","transform:scale(0.85,0.85)")
    })
    dos.addEventListener("mouseup",function(){
      dos.setAttribute("style","transform:scale(1,1)")
    })

  var tres = document.getElementById("3");
  tres.addEventListener("click", function() {
    Calculadora.escribir("3");
  })
    tres.addEventListener("mousedown",function(){
      tres.setAttribute("style","transform:scale(0.85,0.85)")
    })
    tres.addEventListener("mouseup",function(){
      tres.setAttribute("style","transform:scale(1,1)")
    })

  var cuatro = document.getElementById("4");
  cuatro.addEventListener("click", function() {
    Calculadora.escribir("4");
  })
  cuatro.addEventListener("mousedown",function(){
      cuatro.setAttribute("style","transform:scale(0.85,0.85)")
    })
    cuatro.addEventListener("mouseup",function(){
      cuatro.setAttribute("style","transform:scale(1,1)")
    })

  var cinco = document.getElementById("5");
  cinco.addEventListener("click", function() {
    Calculadora.escribir("5");
  })
    cinco.addEventListener("mousedown",function(){
      cinco.setAttribute("style","transform:scale(0.85,0.85)")
    })
    cinco.addEventListener("mouseup",function(){
      cinco.setAttribute("style","transform:scale(1,1)")
    })

  var seis = document.getElementById("6");
  seis.addEventListener("click", function() {
    Calculadora.escribir("6");
  })
  seis.addEventListener("mousedown",function(){
    seis.setAttribute("style","transform:scale(0.85,0.85)")
  })
  seis.addEventListener("mouseup",function(){
    seis.setAttribute("style","transform:scale(1,1)")
  })

  var siete = document.getElementById("7");
  siete.addEventListener("click", function() {
    Calculadora.escribir("7");
  })
  siete.addEventListener("mousedown",function(){
    siete.setAttribute("style","transform:scale(0.85,0.85)")
  })
  siete.addEventListener("mouseup",function(){
    siete.setAttribute("style","transform:scale(1,1)")
  })

  var ocho = document.getElementById("8");
  ocho.addEventListener("click", function() {
    Calculadora.escribir("8");
  })
    ocho.addEventListener("mousedown",function(){
      ocho.setAttribute("style","transform:scale(0.85,0.85)")
    })
    ocho.addEventListener("mouseup",function(){
      ocho.setAttribute("style","transform:scale(1,1)")
    })

  var nueve = document.getElementById("9");
  nueve.addEventListener("click", function() {
    Calculadora.escribir("9");
  })
  nueve.addEventListener("mousedown",function(){
    nueve.setAttribute("style","transform:scale(0.85,0.85)")
  })
  nueve.addEventListener("mouseup",function(){
    nueve.setAttribute("style","transform:scale(1,1)")
  })

  var cero = document.getElementById("0");
  cero.addEventListener("click", function() {
    Calculadora.escribir("0");
  })
  cero.addEventListener("mousedown",function(){
    cero.setAttribute("style","transform:scale(0.85,0.85)")
  })
  cero.addEventListener("mouseup",function(){
    cero.setAttribute("style","transform:scale(1,1)")
  })

  var on = document.getElementById("on");
  on.addEventListener("click",function(){
    if(Calculadora.pantalla.textContent==="0"){
      Calculadora.pantalla.textContent="0";
    }else{
      Calculadora.pantalla.textContent="0";
    }
  })
  on.addEventListener("mousedown",function(){
    on.setAttribute("style","transform:scale(0.85,0.85)")
  })
  on.addEventListener("mouseup",function(){
    on.setAttribute("style","transform:scale(1,1)")
  })

  var punto = document.getElementById("punto");
  punto.addEventListener("click",function(){
    if(Calculadora.pantalla.textContent==="0"){
      Calculadora.pantalla.textContent=".";
    }else{
      Calculadora.pantalla.textContent+=".";
    }
  })
  punto.addEventListener("mousedown",function(){
  punto.setAttribute("style","transform:scale(0.85,0.85)")
  })
  punto.addEventListener("mouseup",function(){
  punto.setAttribute("style","transform:scale(1,1)")
  })

  var contadorPuntos =0;
  punto.addEventListener("click", function () {
  if (contadorPuntos === "0") {
  Calculadora.pantalla.textContent += ".";
  contadorPuntos = 1;
  }
  })

  var signo = document.getElementById("sign");
  signo.addEventListener("click",function(){
  if(Calculadora.pantalla.textContent!=="0"){
  var signo2 = Calculadora.pantalla.textContent * (-1);
  Calculadora.pantalla.textContent = signo2;
  }
  })
  signo.addEventListener("mousedown",function(){
  signo.setAttribute("style","transform:scale(0.85,0.85)")
  })
  signo.addEventListener("mouseup",function(){
  signo.setAttribute("style","transform:scale(1,1)")
  })

  var suma=document.getElementById("mas");
  suma.addEventListener("click",function () {
  Calculadora.numero1=display.innerHTML
  Calculadora.operacion="+"
  Calculadora.pantalla.textContent=""
  })
  mas.addEventListener("mousedown",function(){
  mas.setAttribute("style","transform:scale(0.85,0.85)")
  })
  mas.addEventListener("mouseup",function(){
  mas.setAttribute("style","transform:scale(1,1)")
  })

  var resta=document.getElementById("menos");
  resta.addEventListener("click",function () {
  Calculadora.numero1=display.innerHTML
  Calculadora.operacion="-"
  Calculadora.pantalla.textContent=""
  })
  resta.addEventListener("mousedown",function(){
  resta.setAttribute("style","transform:scale(0.85,0.85)")
  })
  resta.addEventListener("mouseup",function(){
  resta.setAttribute("style","transform:scale(1,1)")
  })

  var multiplicacion=document.getElementById("por");
  multiplicacion.addEventListener("click",function () {
  Calculadora.numero1=display.innerHTML
  Calculadora.operacion="*"
  Calculadora.pantalla.textContent=""
  })
  multiplicacion.addEventListener("mousedown",function(){
  multiplicacion.setAttribute("style","transform:scale(0.85,0.85)")
  })
  multiplicacion.addEventListener("mouseup",function(){
  multiplicacion.setAttribute("style","transform:scale(1,1)")
  })

  var division=document.getElementById("dividido");
  division.addEventListener("click",function () {
  Calculadora.numero1=display.innerHTML
  Calculadora.operacion="/"
  Calculadora.pantalla.textContent=""
  })
  division.addEventListener("mousedown",function(){
  division.setAttribute("style","transform:scale(0.85,0.85)")
  })
  division.addEventListener("mouseup",function(){
  division.setAttribute("style","transform:scale(1,1)")
  })

  var raiz=document.getElementById("raiz");
  raiz.addEventListener("mousedown",function(){
  raiz.setAttribute("style","transform:scale(0.85,0.85)")
  })
  raiz.addEventListener("mouseup",function(){
  raiz.setAttribute("style","transform:scale(1,1)")
  })

  var igual=document.getElementById("igual");
  igual.addEventListener("click",function () {
  Calculadora.numero2 = display.innerHTML
  Calculadora.resolver()
  })
  igual.addEventListener("mousedown",function(){
  igual.setAttribute("style","transform:scale(0.85,0.85)")
  })
  igual.addEventListener("mouseup",function(){
  igual.setAttribute("style","transform:scale(1,1)")
  })
},

resolver: function (){
var resultado=0
switch (Calculadora.operacion) {
  case "+":
  resultado = parseFloat(Calculadora.numero1)+parseFloat(Calculadora.numero2)
    break;
  case "-":
    resultado = parseFloat(Calculadora.numero1)-parseFloat(Calculadora.numero2)
    break;
    case "/":
      resultado = parseFloat(Calculadora.numero1)/parseFloat(Calculadora.numero2)
      break;
      case "*":
        resultado = parseFloat(Calculadora.numero1)*parseFloat(Calculadora.numero2)
        break;
}
Calculadora.numero1 = "";
Calculadora.numero2  = "";
Calculadora.operacion = "";
display.innerHTML = resultado;
},
}

Calculadora.init ()
